<html>
<head>
<title>UOU Official Website</title>
<style>
body{background-color:#2c3940;padding:0;margin:0;}
.ban{width:100%;height:38px;background-color:#1b262e;color:#bbb;text-align:center;padding-top:10px;}
</style>
</head>
<body>
<div class='ban'>Official Website Is Coming Soon</div>
</body>
</html>
