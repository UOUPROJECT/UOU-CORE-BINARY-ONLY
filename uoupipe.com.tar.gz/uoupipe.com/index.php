<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="author" content="John Doe">
    <meta name="description" content="">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>UOU Official Home</title>
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.ico" />
    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body data-spy="scroll" data-target="#primary-menu">

    <div class="preloader">
        <div class="sk-folding-cube">
            <div class="sk-cube1 sk-cube"></div>
            <div class="sk-cube2 sk-cube"></div>
            <div class="sk-cube4 sk-cube"></div>
            <div class="sk-cube3 sk-cube"></div>
        </div>
    </div>
    <!--Mainmenu-area-->
    <div class="mainmenu-area" data-spy="affix" data-offset-top="100">
        <div class="container">
            <!--Logo-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand logo">
					<img src="images/uou logo.png" />
                </a>
            </div>
            <!--Logo/-->
            <nav class="collapse navbar-collapse" id="primary-menu">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a href="#home-page">Home</a></li>
                    <li><a href="#service-page">Whats UOU</a></li>
                    <li><a href="#about-page">Features</a></li>
					<li><a href="#roadmap-page">Roadmap</a></li>					
                    <!--<li><a href="#team-page">How it works</a></li>
                    <li><a href="#price-page">Cost</a></li>  -->                  
                    <li><a href="#faq-page">FAQ</a></li>
                    <li><a href="#contact-page">Contact</a></li>
                </ul>
            </nav>
        </div>
    </div>
    <!--Mainmenu-area/-->



    <!--Header-area-->
    <header class="header-area overlay full-height relative v-center" id="home-page">
        <div class="absolute anlge-bg"></div>
        <div class="container">
            <div class="row v-center">
                <div class="col-xs-12 col-md-7 header-text">
                    <h2>A Peer-to-Peer Anonymous Messaging System</h2>
                    <p>The UOU Pipe project is an attempt on the improvement of message security. No one
can be sure that it will succeed. Many ideas may end up failing. However, the human
pursuit of self-security, property security, and privacy protection has never stopped,
which is the biggest driving force for the development of UOU project. This white
paper is the first draft of the UOU Pipe project white paper. There are many
imperfections in the content. It may be further revised in the future. Should there be
an updated version, we will post it on the official website. Thank you, all participants
and contributors of UOU project, for the trust and support!</p>
                </div>
                <div class="hidden-xs hidden-sm col-md-5 text-right">
                            <img src="images/logo.png" alt="">
                </div>
            </div>
        </div>
    </header>
    <!--Header-area/-->



    <!--Feature-area-->
    <section class="gray-bg section-padding" id="service-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/service-icon-1.png" alt="">
                        </div>
                        <h4>anonymous messaging</h4>
                        <p>UOU Pipe is based on blockchain technology. It will establish the decentralized network according to the distributed terminal nodes. Message transmission relies on peer to peer encryption transfer.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/service-icon-2.png" alt="">
                        </div>
                        <h4>Message Transmission & Its Security</h4>
                        <p>The transmission of messages on traditional networks is not encrypted and can be easily intercepted. The messages transmitted on the UOU network is encrypted and requires a cryptographic algorithm to decrypt the information.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/service-icon-3.png" alt="">
                        </div>
                        <h4>Pipe ownership transfer</h4>
                        <p>A pipe owner can transfer the ownership of the pipe to other people. There will be mining fee attached to the transfer process. The new pipe owner will have to cover this expenses via UOU coin.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Feature-area/-->

    <section class="angle-bg sky-bg section-padding" id="about-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div id="caption_slide" class="carousel slide caption-slider" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="item active row">
                                <div class="v-center">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="caption-title" data-animation="animated fadeInUp">
                                            <h2>Abstract</h2>
                                        </div>
                                        <div class="caption-desc" data-animation="animated fadeInUp">
                                            <p>UOU Pipe is based on the needs of personal privacy. In our daily life, we have a lot of
privacy requirements. For example, chat messages can't eavesdrop, email accounts
can't be banned or closed by any other people, and personal assets need to be safely
stored and transferred. But the reality is that chat messages are exposed to the data of
centralized service provider, email accounts can be banned and shut down by the
email service provider at any time, and personal asset lists are in the bank's database.
It can be said that personal privacy hasn't been protected effectively. UOU Pipe wants
to change this situation, diversify the way people connect with each other, make the
communication channels more secure and private, making the storage and transaction
of personal assets non-traceable.</p>
                                        </div>
                                        <!-- <div class="caption-button" data-animation="animated fadeInUp">
                                            <a href="#" class="button">Read more</a>
                                        </div> -->
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo one" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-4.png" alt="">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo two" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-6.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item row">
                                <div class="v-center">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="caption-title" data-animation="animated fadeInUp">
                                            <h2>The Blackchain</h2>
                                        </div>
                                        <div class="caption-desc" data-animation="animated fadeInUp">
                                            <p>It
enables one to transfer control of that digital representation to someone else. Of the
many potential uses for blockchain technology, cryptocurrency comes first. Till now,
the first and the most successful application of blockchain technology is Bitcoin. Now
UOU will apply block-chain to anonymous messaging communication.</p>
                                        </div>
                                        <!-- <div class="caption-button" data-animation="animated fadeInUp">
                                            <a href="#" class="button">Read more</a>
                                        </div>-->
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo one" data-animation="animated fadeInRight">
                                            <img src="images/service-icon-4.png" alt="">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo two" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-1.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item row">
                                <div class="v-center">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="caption-title" data-animation="animated fadeInUp">
                                            <h2>UOU Pipe has four major functions</h2>
                                        </div>
                                        <div class="caption-desc" data-animation="animated fadeInUp">
                                            <p>1) Crypto message transfer function: address-to-address crypto message transfer.
2) Message broadcast function: address to pipe crypto message broadcast.
3) The SDK is available to the third-party developers, which allows third-party
developers to access UOU network by invoking properties and methods of packages
to implement personalized DAPP.
4) Ecosystem: UOU Pipe is a whole set of an ecosystem, which has well-designed
economic models. Every participant has his own clearly defined roles, production</p>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo one" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-3.png" alt="">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo two" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-6.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item row">
                                <div class="v-center">
                                    <div class="col-xs-12 col-md-6">
                                        <div class="caption-title" data-animation="animated fadeInUp">
                                            <h2>UOU Pipe is a platform</h2>
                                        </div>
                                        <div class="caption-desc" data-animation="animated fadeInUp">
                                            <p>In essence, UOU is not only a currency, but it's also a platform indeed and has the
function of currency (not member point):
1) Users can use UOU send different types of message anonymously.
2) UOU provides an open network access interface, so third-party Dapp can use the
features of UOU.
3) It can continuously generate new coins by POW mining.
4) A user can use UOU to transfer the value from the network safely.</p>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo one" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-5.png" alt="">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-md-3">
                                        <div class="caption-photo two" data-animation="animated fadeInRight">
                                            <img src="images/portfolio-icon-3.png" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Indicators -->
                        <ol class="carousel-indicators caption-indector">
                            <li data-target="#caption_slide" data-slide-to="0" class="active">
                                <strong>UOU Pipe</strong>A Peer-to-Peer Anonymous Messaging System.
                            </li>
                            <li data-target="#caption_slide" data-slide-to="1">
                                <strong>BLOCKCHAIN</strong>The blockchain is a ledger showing the quantity of something controlled by a user.
                            </li>
                            <li data-target="#caption_slide" data-slide-to="2">
                                <strong>FUNCTIONS</strong>UOU Pipe has four major functions.
                            </li>
                            <li data-target="#caption_slide" data-slide-to="3">
                                <strong>PLATFORM</strong>In essence, UOU is not only a currency, but it's also a platform.
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="gray-bg section-padding" id="roadmap-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <div class="page-title">
                        <h2>Roadmap</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-1.png" alt="">
                        </div>
                        <h3>November 2018</h3>
                        <p>Project launch, release official wallet, pool & CUDA miner.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-2.png" alt="">
                        </div>
                        <h3>February 2019</h3>
                        <p>Improve the community, expand the mining pool and media, exchange list.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-3.png" alt="">
                        </div>
                        <h3>March 2019</h3>
                        <p>Open pipe functions for use, preliminary realization of text messages.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-4.png" alt="">
                        </div>
                        <h3>June 2019</h3>
                        <p>Provide iOS or Android apps for mobile wallet and messaging.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-5.png" alt="">
                        </div>
                        <h3>September 2019</h3>
                        <p>Provide an API that allows DApp developers to access the UOU network.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images/portfolio-icon-6.png" alt="">
                        </div>
                        <h3>December 2019</h3>
                        <p>Provide the capability of pictures, voice, video and streaming.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>




   <!-- <section class="price-area overlay section-padding" id="price-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <div class="page-title">
                        <h2>Afortable Price</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit voluptates, temporibus at, facere harum fugiat!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="price-table">
                        <h3 class="text-uppercase price-title">Basic</h3>
                        <hr>
                        <ul class="list-unstyled">
                            <li><strong class="amount">$ <span class="big">20</span></strong>/Month</li>
                            <li>100 MB Disk Space</li>
                            <li>2 Subdomains</li>
                            <li>5 Email Accounts</li>
                            <li>Webmail Support</li>
                            <li>Customer Support 24/7</li>
                        </ul>
                        <hr>
                        <a href="#" class="button">Purchase</a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="price-table active">
                        <span class="price-info"><span class="ti-crown"></span></span>
                        <h3 class="text-uppercase price-title">STABDARD</h3>
                        <hr>
                        <ul class="list-unstyled">
                            <li><strong class="amount">$ <span class="big">39</span></strong>/Month</li>
                            <li>100 MB Disk Space</li>
                            <li>2 Subdomains</li>
                            <li>5 Email Accounts</li>
                            <li>Webmail Support</li>
                            <li>Customer Support 24/7</li>
                        </ul>
                        <hr>
                        <a href="#" class="button">Purchase</a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="price-table">
                        <h3 class="text-uppercase price-title">UNLIMITED</h3>
                        <hr>
                        <ul class="list-unstyled">
                            <li><strong class="amount">$ <span class="big">59</span></strong>/Month</li>
                            <li>100 MB Disk Space</li>
                            <li>2 Subdomains</li>
                            <li>5 Email Accounts</li>
                            <li>Webmail Support</li>
                            <li>Customer Support 24/7</li>
                        </ul>
                        <hr>
                        <a href="#" class="button">Purchase</a>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="section-padding gray-bg" id="team-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <div class="page-title">
                        <h2>Special team</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit voluptates, temporibus at, facere harum fugiat!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="single-team">
                        <div class="team-photo">
                            <img src="images/team-section-1.png" alt="">
                        </div>
                        <h4>JEMY SEDONCE</h4>
                        <h6>Co. Founder</h6>
                        <ul class="social-menu">
                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="single-team">
                        <div class="team-photo">
                            <img src="images/team-section-2.png" alt="">
                        </div>
                        <h4>DEBORAH BROWN</h4>
                        <h6>UX Designer</h6>
                        <ul class="social-menu">
                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="single-team">
                        <div class="team-photo">
                            <img src="images/team-section-3.png" alt="">
                        </div>
                        <h4>HARRY BANKS</h4>
                        <h6>Founder</h6>
                        <ul class="social-menu">
                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="single-team">
                        <div class="team-photo">
                            <img src="images/team-section-4.png" alt="">
                        </div>
                        <h4>VICTORIA CLARK</h4>
                        <h6>Creative Director</h6>
                        <ul class="social-menu">
                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <section class="testimonial-area section-padding gray-bg overlay">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <div class="page-title">
                        <h2>Client says</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit voluptates, temporibus at, facere harum fugiat!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                    <div class="testimonials">
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-1.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-2.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-3.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-4.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-5.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                        <div class="testimonial">
                            <div class="testimonial-photo">
                                <img src="images/avatar-small-6.png" alt="">
                            </div>
                            <h3>AR Rahman</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel vero dolore officiis, velit id libero illum harum hic magni, quae repellendus adipisci possimus saepe nostrum doloribus repudiandae asperiores commodi voluptate.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
<section class="section-padding overlay client-area overlay" id="client-page">
        <div class="container">
            <div class="row text-center">
                <div class="col-xs-12">
                    <div class="clients">
                        <div class="item item_home">
                            <a href="https://github.com/UOUPROJECT/UOU-CORE-BINARY-ONLY/blob/master/UOU-Core-for-Windows.rar" target="_blank"><img src="images/wallet.jpg"><br/>Windows Wallet</a>
                        </div>
                        <div class="item item_home">
                            <a href="https://github.com/UOUPROJECT/UOU-CORE-BINARY-ONLY/blob/master/uou-core-linux-ubuntu.tar.gz" target="_blank"><img src="images/wallet.jpg"><br/>Linux Wallet</a>
                        </div>
                        <div class="item item_home">
                            <a href="http://scan.uoupipe.com/" target="_blank"><img src="images/explorer.png"><br/>Explorer</a>
                        </div>
                        <div class="item item_home">
                            <a href="https://github.com/UOUPROJECT/UOUMiner-Binary-Only" target="_blank"><img src="images/mining tool.png"><br/>Mining tool</a>
                        </div>
                        <div class="item item_home">
                            <a href="https://miningpoolstats.stream/uoupipe" target="_blank"><img src="images/pool.jpg"><br/>Mining pools</a>
                        </div>
                        <div class="item item_home">
                            <a href="https://cdn.discordapp.com/attachments/510134764087410718/520976731012857856/UOUPipe_White_Paper_-_EN.pdf" target="_blank"><img src="images/whitepaper.jpg"><br/>White paper</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





    <section class="gray-bg section-padding" id="faq-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <div class="page-title">
                        <h2>Frequently Asked Questions</h2>
                        <p>For more information please download from <a href="images/white.pdf" target="_blank">here</a>!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                    <div class="panel-group" id="accordion">
                        <div class="panel">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true">What is UOU Pipe?</a>
                            </h4>
                            <div id="collapse1" class="panel-collapse collapse in">
                                <p>UOU Pipe is based on blockchain technology. It will establish the decentralized
network according to the distributed terminal nodes. Message transmission relies on
peer to peer encryption transfer. Because two terminals of the information
transmission are encrypted, the third party will never know who they are and where
they are.</p>
                            </div>
                        </div>
                        <div class="panel">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">What is Level of Pipe?</a>
                            </h4>
                            <div id="collapse2" class="panel-collapse collapse">
                                <p>The level of the pipe is defined into three categories in terms of the degree of usage:
								<ul><li>Top Level</li><li>Sub Level</li><li>Final Level</li></ul>
Messages can be classified into different categories. A classification that is too
detailed may be difficult to understand and apply. The three level of pipe covers the
needs of most messages classification.</p>
                            </div>
                        </div>
                        <div class="panel">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">What is Economic Model?</a>
                            </h4>
                            <div id="collapse3" class="panel-collapse collapse">
                                <p>On the UOU network, there are multiple roles as follows: Miners, Pipe Worker, General Node, Cache Node, Content Service Provider, UOU Operators, Audiences and 3rd-party DAPP.</p>
                            </div>
                        </div>
                        <div class="panel">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">The Economic Relationship Between UOU Pipes At All Levels</a>
                            </h4>
                            <div id="collapse4" class="panel-collapse collapse">
                                <p>The UOU pipe is built on the three-level pipe model. The FINAL pipe is used for
communication. The other two types of pipes are mainly used for classification. Of
course, the two levels can be used for communication as well, but if a node is linked
to TOP or the SUB pipe, it will receive all the message from the subordinated final
pipe, it will not be easy to manage and use that huge amount of messages.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>








    

<!--
    <section class="section-padding gray-bg" id="blog-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="single-blog">
                        <div class="blog-photo">
                            <img src="images/small1.jpg" alt="">
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">Beautiful Place for your Great Journey</a></h3>
                            <ul class="blog-meta">
                                <li><span class="ti-user"></span> <a href="#">Admin</a></li>
                                <li><span class="ti-calendar"></span> <a href="#">Feb 01, 2017</a></li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit nemo eaque expedita aliquid dolorem repellat perferendis, facilis aut fugit, impedit.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="single-blog">
                        <div class="blog-photo">
                            <img src="images/small2.jpg" alt="">
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">Beautiful Place for your Great Journey</a></h3>
                            <ul class="blog-meta">
                                <li><span class="ti-user"></span> <a href="#">Admin</a></li>
                                <li><span class="ti-calendar"></span> <a href="#">Feb 01, 2017</a></li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit nemo eaque expedita aliquid dolorem repellat perferendis, facilis aut fugit, impedit.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="single-blog">
                        <div class="blog-photo">
                            <img src="images/small3.jpg" alt="">
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">Beautiful Place for your Great Journey</a></h3>
                            <ul class="blog-meta">
                                <li><span class="ti-user"></span> <a href="#">Admin</a></li>
                                <li><span class="ti-calendar"></span> <a href="#">Feb 01, 2017</a></li>
                            </ul>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit nemo eaque expedita aliquid dolorem repellat perferendis, facilis aut fugit, impedit.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

-->



    <footer class="footer-area relative sky-bg" id="contact-page">
        <div class="absolute footer-bg"></div>
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                        <div class="page-title">
                            <h2>Contact with us</h2>
                            <p>Please contact us for more details!</p>
                        </div>
                    </div>
                </div>
                <!--  <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <address class="side-icon-boxe">
                            <div class="side-icon-box col-md-4">
                                <div class="side-icon">
                                    <img src="images/location-arrow.png" alt="">
                                </div>
                                <p><strong>Address: </strong> xxx, xxx <br />Sydney</p>
                            </div>
                            <div class="side-icon-box col-md-4">
                                <div class="side-icon">
                                    <img src="images/phone-arrow.png" alt="">
                                </div>
                                <p><strong>Telephone: </strong>
                                    <a href="callto:8801812726495">+61 2 000 0000</a> <br />
                                    <a href="callto:8801687420471">+61 2 000 0000</a>
                                </p>
                            </div>
                            <div class="side-icon-box col-md-4">
                                <div class="side-icon">
                                    <img src="images/mail-arrow.png" alt="">
                                </div>
                                <p><strong>E-mail: </strong>
                                    <a href="mailto:youremail@xxxx.com">youremail@xxxx.com</a> <br />
                                    <a href="mailto:youremail@xxxx.com">example@xxxx.com</a>
                                </p>
                            </div>
                        </address>
                    </div>
                   <div class="col-xs-12 col-md-8">
                        <form action="process.php" id="contact-form" method="post" class="contact-form">
                            <div class="form-double">
                                <input type="text" id="form-name" name="form-name" placeholder="Your name" class="form-control" required="required">
                                <input type="email" id="form-email" name="form-email" class="form-control" placeholder="E-mail address" required="required">
                            </div>
                            <input type="text" id="form-subject" name="form-subject" class="form-control" placeholder="Message topic">
                            <textarea name="message" id="form-message" name="form-message" rows="5" class="form-control" placeholder="Your message" required="required"></textarea>
                            <button type="sibmit" class="button">Submit</button>
                        </form>
                    </div>
                </div>  -->
            </div>
        </div>      
        <div class="footer-middle">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 pull-right">
                        <ul class="social-menu text-right x-left">
                            <li><a href="https://bitcointalk.org/index.php?topic=5071341.0"><img src="images/bitcoin.png" height="10"></a></li>
                            <li><a href="https://twitter.com/sarah65932686"><i class="ti-twitter"></i></a></li>
                            <li><a href="https://discord.gg/VZNanwP"><img src="images/discord.png" height="10"></a></li>
                            <li><a href="https://github.com/uouproject"><i class="ti-github"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-xs-12 col-sm-6">
                        <p>Follow us from social media.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <p>&copy;Copyright 2018 All right resurved. ubiquitous</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>





    <!--Vendor-JS-->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <!--Plugin-JS-->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.parallax-1.1.3.js"></script>
    <script src="js/scrollUp.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <!--Main-active-JS-->
    <script src="js/main.js"></script>
</body>

</html>
